import React, {Component, Fragment} from 'react';
import {Button} from 'reactstrap';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import CharacterSlot_1 from './FirstSlot';
import CharacterSlot_2 from './SecondSlot';
import CharacterSlot_3 from './ThirdSlot';

import {
    Row, Col,
    Card, CardImg, CardText, CardBody,
    CardTitle, CardSubtitle, CardLink, CardHeader, CardFooter
} from 'reactstrap';


class CardsBasic extends Component {

    render() {
        return (
            <Fragment>
                <ReactCSSTransitionGroup
                    component="div"
                    transitionName="TabsAnimation"
                    transitionAppear={true}
                    transitionAppearTimeout={0}
                    transitionEnter={false}
                    transitionLeave={false}>
                    <Row>
                        <Col md="4">
                            <CharacterSlot_1 />
                        </Col>
                        <Col md="4">
                            <CharacterSlot_2 />
                        </Col>
                        <Col md="4">
                            <CharacterSlot_3 />
                        </Col>
                    </Row>
                </ReactCSSTransitionGroup>
            </Fragment>
        );
    }
};

export default CardsBasic;
