import React, { Component, Fragment } from "react";
import { Button } from "reactstrap";
import ReactCSSTransitionGroup from "react-addons-css-transition-group";

import {
  Row,
  Col,
  Card,
  CardImg,
  CardText,
  CardBody,
  CardTitle,
  CardSubtitle,
  CardLink,
  CardHeader,
  CardFooter,
} from "reactstrap";

class CharacterSlot_3 extends Component {
  render() {
    return (
      <Fragment>
        <ReactCSSTransitionGroup
          component="div"
          transitionName="TabsAnimation"
          transitionAppear={true}
          transitionAppearTimeout={0}
          transitionEnter={false}
          transitionLeave={false}
          id="cards"
        >
          <Card className="main-card mb-3" id="slot">
            <CardBody>
              <p className="secondcard-title">SLOT 3</p>
              <p className="secondcard-subtitle">BLOCKS</p>
              <div className="plus-button">
                <i class="fas fa-lock fa-9x"></i>
              </div>
              <div className="slot3-link">
                <a>Why can't I create another character</a>
              </div>
            </CardBody>
          </Card>
        </ReactCSSTransitionGroup>
      </Fragment>
    );
  }
}

export default CharacterSlot_3;
