import React, {Fragment} from 'react';

import Tabs from 'react-responsive-tabs';

import PageTitle from '../../../Layout/AppMain/PageTitle';

// Examples
import CardsBasicExample from './Examples/Basic';
import CardsColors from './Examples/FirstSlot';
import './slots.css';

const tabsContent = [
    {
        title: '',
        content: <CardsBasicExample/>
    }
];

function getTabs() {
    return tabsContent.map((tab, index) => ({
        title: tab.title,
        getContent: () => tab.content,
        key: index,
    }));
}

export default class CardsExamples extends React.Component {

    render() {

        return (
            <Fragment>
                <CardsBasicExample />
            </Fragment>
        );
    }
}